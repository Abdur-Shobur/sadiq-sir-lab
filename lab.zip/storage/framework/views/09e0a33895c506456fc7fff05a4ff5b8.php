<!-- Start Navbar Area -->
<div class="navbar-area">
    <div class="labto-mobile-nav">
        <div class="logo">
            <a href="<?php echo e(route('home')); ?>">
                <?php if(\App\Models\Setting::getValue('logo')): ?>
                    <img style="max-height: 60px;" src="<?php echo e(asset('uploads/' . \App\Models\Setting::getValue('logo'))); ?>" alt="<?php echo e(\App\Models\Setting::getValue('site_name', 'lab')); ?>" />
                <?php else: ?>
                    <img style="max-height: 60px;" src="<?php echo e(asset('assets/img/logo.png')); ?>" alt="<?php echo e(\App\Models\Setting::getValue('site_name', 'Prof. Sadiq Lab')); ?>" />
                <?php endif; ?>
            </a>
        </div>
    </div>

    <div class="labto-nav">
        <div class="container">
            <nav class="navbar navbar-expand-md navbar-light">
                <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
                    <?php if(\App\Models\Setting::getValue('logo')): ?>
                        <img style="max-height: 60px;" src="<?php echo e(asset('uploads/' . \App\Models\Setting::getValue('logo'))); ?>" alt="<?php echo e(\App\Models\Setting::getValue('site_name', 'Prof. Sadiq Lab')); ?>" />
                    <?php else: ?>
                        <img style="max-height: 60px;" src="<?php echo e(asset('assets/img/logo.png')); ?>" alt="<?php echo e(\App\Models\Setting::getValue('site_name', 'Prof. Sadiq Lab')); ?>" />
                    <?php endif; ?>
                </a>

                <div class="collapse navbar-collapse mean-menu" id="navbarSupportedContent">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a href="<?php echo e(route('home')); ?>" class="nav-link <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>">Home</a>
                        </li>
                        <!-- <li class="nav-item">
                            <a href="<?php echo e(route('research')); ?>" class="nav-link <?php echo e(request()->routeIs('research*') ? 'active' : ''); ?>">Publications</a>
                        </li> -->
                        <li class="nav-item">
                            <a href="<?php echo e(route('publications')); ?>" class="nav-link <?php echo e(request()->routeIs('publications') ? 'active' : ''); ?>">Publications</a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('projects')); ?>" class="nav-link <?php echo e(request()->routeIs('projects') ? 'active' : ''); ?>">Projects</a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('team')); ?>" class="nav-link <?php echo e(request()->routeIs('team') ? 'active' : ''); ?>">Team</a>
                        </li>

                        <li class="nav-item">
                            <a href="<?php echo e(route('blog')); ?>" class="nav-link <?php echo e(request()->routeIs('blog') ? 'active' : ''); ?>">Blog</a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('events')); ?>" class="nav-link <?php echo e(request()->routeIs('events') ? 'active' : ''); ?>">Events</a>
                        </li>
                    </ul>

                    <div class="others-options">
                        <a href="<?php echo e(route('contact')); ?>" class="btn btn-secondary">Let's Talk</a>
                    </div>
                </div>
            </nav>
        </div>
    </div>
</div>
<!-- End Navbar Area -->
<?php /**PATH D:\BU\sadiq-sir-lab\resources\views/components/navbar.blade.php ENDPATH**/ ?>