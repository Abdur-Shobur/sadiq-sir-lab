

<?php $__env->startSection('title', 'Research Areas Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="mt-4">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
            <li class="breadcrumb-item active" aria-current="page">Research Areas Management</li>
        </ol>
    </nav>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4>Research Areas Management</h4>
                    <a href="<?php echo e(route('dashboard.research-areas.create')); ?>" class="btn btn-primary">
                        <i class="fas fa-plus"></i>
                        <span class="d-none d-lg-inline-block">Add New Research Area</span>
                    </a>
                </div>
                <div class="card-body">
                    <?php if($researchAreas->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Order</th>
                                        <th>Image</th>
                                        <th>Title</th>
                                        <th>Status</th>
                                        <th>Created</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $researchAreas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $researchArea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($researchArea->order); ?></td>
                                            <td>
                                                <?php if($researchArea->image): ?>
                                                    <img src="<?php echo e(asset('uploads/' . $researchArea->image)); ?>"
                                                         alt="Research Area"
                                                         style="width: 80px; height: 60px; object-fit: cover; border-radius: 5px;">
                                                <?php else: ?>
                                                    <span class="text-muted">No image</span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($researchArea->title); ?></td>

                                            <td>
                                                <?php if($researchArea->is_active): ?>
                                                    <span class="badge bg-success">Active</span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary">Inactive</span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($researchArea->created_at->format('M d, Y')); ?></td>
                                            <td>
                                                <div class="btn-group gap-2" role="group">
                                                <a href="<?php echo e(route('dashboard.research-areas.show', $researchArea)); ?>"
                                                    class="btn btn-sm btn-info">
                                                    <i class="fas fa-eye"></i>
                                                    </a>
                                                <a href="<?php echo e(route('dashboard.research-areas.edit', $researchArea)); ?>"
                                                   class="btn btn-sm btn-primary">
                                                    <i class="fas fa-edit"></i>
                                                    </a>
                                                <button type="button" class="btn btn-sm btn-danger"
                                                        onclick="confirmDelete('<?php echo e(route('dashboard.research-areas.destroy', $researchArea)); ?>', '<?php echo e($researchArea->title); ?>')">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-4">
                            <p class="text-muted">No research areas found.</p>
                            <a href="<?php echo e(route('dashboard.research-areas.create')); ?>" class="btn btn-primary">Create First Research Area</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Delete Confirmation Script -->
<script>
    function confirmDelete(url, title) {
        Swal.fire({
            title: 'Are you sure?',
            text: `Do you want to delete the research area "${title}"?`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                // Create a form and submit it
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = url;
                form.innerHTML = `
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                `;
                document.body.appendChild(form);
                form.submit();
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\BU\sadiq-sir-lab\resources\views/dashboard/research-areas/index.blade.php ENDPATH**/ ?>