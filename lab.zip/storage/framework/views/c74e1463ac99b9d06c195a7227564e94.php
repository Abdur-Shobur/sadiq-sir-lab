

<?php $__env->startSection('content'); ?>
<div>
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
            <li class="breadcrumb-item active" aria-current="page">Teams</li>
        </ol>
    </nav>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4>Teams</h4>
                    <a href="<?php echo e(route('dashboard.teams.create')); ?>" class="btn btn-primary">
                        <i class="fas fa-plus"></i>
                        <span class="d-none d-lg-inline-block">Create New</span>
                    </a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th class="text-center">Image</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Designation</th>
                                    <th>Roles</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center">
                                        <?php if($team->image): ?>
                                        <img src="<?php echo e($team->image_url); ?>" alt="<?php echo e($team->name); ?>"
                                             class="rounded-circle" width="50" height="50" style="object-fit: cover;">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('assets/img/placeholder.svg')); ?>" alt="<?php echo e($team->name); ?>"
                                                 class="rounded-circle" width="50" height="50" style="object-fit: cover;">
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($team->name); ?></td>
                                    <td><?php echo e($team->email); ?></td>
                                    <td><?php echo e($team->designation); ?></td>
                                    <td>
                                        <?php if($team->roles->count() > 0): ?>
                                            <?php $__currentLoopData = $team->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <span class="badge bg-<?php echo e($role->slug === 'admin' ? 'danger' : ($role->slug === 'advisor' ? 'warning' : 'info')); ?> me-1">
                                                    <?php echo e($role->name); ?>

                                                </span>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <span class="text-muted">No roles assigned</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php echo e($team->is_active ? 'success' : 'secondary'); ?>">
                                            <?php echo e($team->is_active ? 'Active' : 'Inactive'); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <div class="btn-group gap-2" role="group">
                                            <a href="<?php echo e(route('dashboard.teams.show', $team)); ?>"
                                               class="btn btn-sm btn-info" title="View Details">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="<?php echo e(route('dashboard.teams.edit', $team)); ?>"
                                               class="btn btn-sm btn-warning" title="Edit">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <button type="button" class="btn btn-sm btn-danger delete-team"
                                                    data-id="<?php echo e($team->id); ?>"
                                                    data-name="<?php echo e($team->name); ?>"
                                                    title="Delete">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <?php if($teams->hasPages()): ?>
                        <div class="d-flex justify-content-center mt-4">
                            <?php echo e($teams->links('pagination.bootstrap-4-custom')); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if($teams->isEmpty()): ?>
<div class="text-center py-5">
    <i class="fas fa-users fa-3x text-muted mb-3"></i>
    <h4 class="text-muted">No Team Members Found</h4>
    <p class="text-muted">Get started by adding your first team member.</p>
    <a href="<?php echo e(route('dashboard.teams.create')); ?>" class="btn btn-primary">
        <i class="fas fa-plus"></i> Add First Team Member
    </a>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize DataTable if you're using it
    if (typeof $ !== 'undefined' && $.fn.DataTable) {
        $('#dataTable').DataTable({
            "pageLength": 10,
            "order": [[1, "asc"]], // Sort by name column
            "language": {
                "search": "Search team members:",
                "lengthMenu": "Show _MENU_ team members per page",
                "info": "Showing _START_ to _END_ of _TOTAL_ team members",
                "infoEmpty": "Showing 0 to 0 of 0 team members",
                "infoFiltered": "(filtered from _MAX_ total team members)"
            }
        });
    }

    // Auto-hide success messages after 5 seconds
    setTimeout(function() {
        const alerts = document.querySelectorAll('.alert-success');
        alerts.forEach(alert => {
            alert.style.transition = 'opacity 0.5s';
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 500);
        });
    }, 5000);

    // Handle delete team buttons
    document.querySelectorAll('.delete-team').forEach(button => {
        button.addEventListener('click', function() {
            const teamId = this.getAttribute('data-id');
            const teamName = this.getAttribute('data-name');

            // Show confirmation toast
            Swal.fire({
                title: 'Delete Team Member?',
                text: `Are you sure you want to delete "${teamName}"?`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    // Create form and submit
                    const form = document.createElement('form');
                    form.method = 'POST';
                    form.action = `/dashboard/teams/${teamId}`;

                    const csrfToken = document.createElement('input');
                    csrfToken.type = 'hidden';
                    csrfToken.name = '_token';
                    csrfToken.value = '<?php echo e(csrf_token()); ?>';

                    const methodField = document.createElement('input');
                    methodField.type = 'hidden';
                    methodField.name = '_method';
                    methodField.value = 'DELETE';

                    form.appendChild(csrfToken);
                    form.appendChild(methodField);
                    document.body.appendChild(form);
                    form.submit();
                }
            });
        });
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\BU\sadiq-sir-lab\resources\views/dashboard/teams/index.blade.php ENDPATH**/ ?>