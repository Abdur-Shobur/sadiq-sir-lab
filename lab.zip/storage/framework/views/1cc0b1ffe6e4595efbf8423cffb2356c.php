<!-- Start CTA Area -->
<?php
    $cta = \App\Models\Cta::active()->first();
?>

<section class="cta-area ptb-120">
    <div class="container">
        <div class="cta-content">
            <?php if($cta): ?>
                <h3 class="mb-3"><?php echo e($cta->title); ?></h3>
                <?php if($cta->subtitle): ?>
                    <h4 class="mb-3 text-white"><?php echo e($cta->subtitle); ?></h4>
                <?php endif; ?>
                <p><?php echo e($cta->description); ?></p>
                <h2><a href="tel:<?php echo e($cta->phone_number); ?>"><?php echo e($cta->phone_number); ?></a></h2>
                <a href="<?php echo e(route('contact')); ?>" class="btn btn-primary"><?php echo e($cta->button_text); ?></a>
            <?php else: ?>
                <!-- Fallback static content -->
                <h3>We'll ensure you always get the best Results</h3>
                <p>
                    Duis aute irure dolor in reprehenderit in voluptate velit esse
                    cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat
                    cupidatat non proident, sunt in culpa qui officia deserunt mollit
                    anim id est laborum.
                </p>
                <h2><a href="tel:+0112343874444">+(01)1234 387 4444</a></h2>
                <a href="<?php echo e(route('contact')); ?>" class="btn btn-primary">Contact Us</a>
            <?php endif; ?>
        </div>
    </div>
</section>
<!-- End CTA Area -->
<?php /**PATH D:\BU\sadiq-sir-lab\resources\views/components/cta.blade.php ENDPATH**/ ?>