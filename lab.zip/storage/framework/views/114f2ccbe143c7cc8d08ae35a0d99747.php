
		<!-- Start Blog Area -->
		<section class="blog-area ptb-120 bg-fff7f4">
			<div class="container">
				<div class="section-title text-center">
					<span class="bg-ff5d24">Blog Update</span>
					<h2>Blog Posts</h2>
					<p>
						Stay updated with the latest blog posts from our team.
					</p>
				</div>

				<div class="row justify-content-center">
					<?php $__empty_1 = true; $__currentLoopData = $blogs->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<div class="col-lg-4 col-md-6">
							<div class="single-blog-post">
								<div class="post-image">
									<a href="<?php echo e(route('blog.detail', $blog->id)); ?>">
										<?php if($blog->image): ?>
										<img src="<?php echo e($blog->image_url); ?>" alt="<?php echo e($blog->title); ?>" />
										<?php else: ?>
											<img src="<?php echo e(asset('assets/img/placeholder.svg')); ?>" alt="<?php echo e($blog->title); ?>" />
										<?php endif; ?>
									</a>

									<div class="date"><?php echo e($blog->created_at->format('d M, Y')); ?></div>
								</div>

								<div class="post-content">
									<span>By: <a href="<?php echo e(route('blog.detail', $blog->id)); ?>"><?php echo e($blog->author ?? 'Admin'); ?></a></span>
									<h3>
										<a href="<?php echo e(route('blog.detail', $blog->id)); ?>">
											<?php echo e($blog->title); ?>

										</a>
									</h3>
									<p>
										<?php echo e(Str::limit($blog->subtitle ?? $blog->content, 120)); ?>

									</p>
									<a href="<?php echo e(route('blog.detail', $blog->id)); ?>" class="learn-more-btn">
										Learn More <i class="flaticon-arrow-pointing-to-right"></i>
									</a>
								</div>
							</div>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<div class="col-12">
							<div class="text-center">
								<p>No blog posts found.</p>
							</div>
						</div>
					<?php endif; ?>
				</div>
			</div>
		</section>
		<!-- End Blog Area -->
<?php /**PATH D:\BU\sadiq-sir-lab\resources\views/components/blog.blade.php ENDPATH**/ ?>