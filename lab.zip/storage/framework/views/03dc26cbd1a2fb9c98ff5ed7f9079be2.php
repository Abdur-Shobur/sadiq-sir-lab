

<?php $__env->startSection('content'); ?>
<div>
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
            <li class="breadcrumb-item active" aria-current="page">Permissions</li>
        </ol>
    </nav>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4>Permissions Management</h4>
                    <!-- <a href="<?php echo e(route('dashboard.permissions.create')); ?>" class="btn btn-primary">
                        <i class="fas fa-plus"></i>
                        <span class="d-none d-lg-inline-block">Create New Permission</span>
                    </a> -->
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Slug</th>
                                    <th>Module</th>
                                    <th>Description</th>
                                    <th>Roles</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <strong><?php echo e($permission->name); ?></strong>
                                    </td>
                                    <td>
                                        <code><?php echo e($permission->slug); ?></code>
                                    </td>
                                    <td>
                                        <span class="badge bg-info"><?php echo e(ucfirst($permission->module)); ?></span>
                                    </td>
                                    <td><?php echo e($permission->description ?? 'N/A'); ?></td>
                                    <td>
                                        <span class="badge bg-secondary"><?php echo e($permission->roles->count()); ?> roles</span>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php echo e($permission->is_active ? 'success' : 'secondary'); ?>">
                                            <?php echo e($permission->is_active ? 'Active' : 'Inactive'); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <div class="btn-group gap-2" role="group">

                                            <button type="button" class="btn btn-sm btn-danger delete-permission"
                                                    data-id="<?php echo e($permission->id); ?>"
                                                    data-name="<?php echo e($permission->name); ?>"
                                                    title="Delete">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <?php if($permissions->hasPages()): ?>
                        <div class="d-flex justify-content-center mt-4">
                            <?php echo e($permissions->links('pagination.bootstrap-4-custom')); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if($permissions->isEmpty()): ?>
<div class="text-center py-5">
    <i class="fas fa-key fa-3x text-muted mb-3"></i>
    <h4 class="text-muted">No Permissions Found</h4>
    <p class="text-muted">Get started by creating your first permission.</p>
    <a href="<?php echo e(route('dashboard.permissions.create')); ?>" class="btn btn-primary">
        <i class="fas fa-plus"></i> Create First Permission
    </a>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize DataTable if you're using it
    if (typeof $ !== 'undefined' && $.fn.DataTable) {
        $('#dataTable').DataTable({
            "pageLength": 15,
            "order": [[2, "asc"], [0, "asc"]], // Sort by module then name
            "language": {
                "search": "Search permissions:",
                "lengthMenu": "Show _MENU_ permissions per page",
                "info": "Showing _START_ to _END_ of _TOTAL_ permissions",
                "infoEmpty": "Showing 0 to 0 of 0 permissions",
                "infoFiltered": "(filtered from _MAX_ total permissions)"
            }
        });
    }

    // Auto-hide success messages after 5 seconds
    setTimeout(function() {
        const alerts = document.querySelectorAll('.alert-success');
        alerts.forEach(alert => {
            alert.style.transition = 'opacity 0.5s';
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 500);
        });
    }, 5000);

    // Handle delete permission buttons
    document.querySelectorAll('.delete-permission').forEach(button => {
        button.addEventListener('click', function() {
            const permissionId = this.getAttribute('data-id');
            const permissionName = this.getAttribute('data-name');

            // Show confirmation toast
            Swal.fire({
                title: 'Delete Permission?',
                text: `Are you sure you want to delete "${permissionName}"?`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    // Create form and submit
                    const form = document.createElement('form');
                    form.method = 'POST';
                    form.action = `/dashboard/permissions/${permissionId}`;

                    const csrfToken = document.createElement('input');
                    csrfToken.type = 'hidden';
                    csrfToken.name = '_token';
                    csrfToken.value = '<?php echo e(csrf_token()); ?>';

                    const methodField = document.createElement('input');
                    methodField.type = 'hidden';
                    methodField.name = '_method';
                    methodField.value = 'DELETE';

                    form.appendChild(csrfToken);
                    form.appendChild(methodField);
                    document.body.appendChild(form);
                    form.submit();
                }
            });
        });
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\BU\sadiq-sir-lab\resources\views/dashboard/permissions/index.blade.php ENDPATH**/ ?>