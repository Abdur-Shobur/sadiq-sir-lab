<!-- Start Main Banner Area -->
<div class="main-banner">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 col-md-12">
                <div class="main-banner-content">
                    <?php if(isset($banner)): ?>
                        <span><?php echo e($banner->subtitle); ?></span>
                        <h1><?php echo e($banner->title); ?></h1>
                        <p><?php echo e($banner->description); ?></p>
                        <a href="<?php echo e($banner->action_button_link); ?>" class="btn btn-primary"><?php echo e($banner->action_button_text); ?></a>
                    <?php else: ?>
                        <span>Laboratory & Science</span>
                        <h1>Science is Nothing But Perception</h1>
                        <p>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                            eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                            enim ad minim veniam, quis nostrud exercitation ullamco laboris
                            nisi ut aliquip ex ea commodo consequat.
                        </p>
                        <a href="<?php echo e(route('contact')); ?>" class="btn btn-primary">Make Appointment</a>
                    <?php endif; ?>
                </div>
            </div>

            <div class="col-lg-6 col-md-12">
                <div class="banner-image">
                    <?php if(isset($banner) && $banner->banner_image): ?>
                        <img src="<?php echo e(asset('uploads/' . $banner->banner_image)); ?>" alt="Banner Image" />
                    <?php else: ?>
                        <img src="<?php echo e(asset('assets/img/banner-img1.png')); ?>" alt="image" />
                    <?php endif; ?>
                    <img src="<?php echo e(asset('assets/img/bg-shape2.png')); ?>" alt="image" />
                </div>
            </div>
        </div>
    </div>


</div>
<!-- End Main Banner Area -->
<?php /**PATH D:\BU\sadiq-sir-lab\resources\views/components/banner.blade.php ENDPATH**/ ?>