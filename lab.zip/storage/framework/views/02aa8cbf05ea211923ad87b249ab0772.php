<!-- Start Team Area -->
<section class="team-area ptb-120">
    <div class="container">
        <div class="section-title">
            <span>Meet Our Team</span>
            <h2>Led by Passionate Experts</h2>
            <p>
                On the other hand we denounce with righteous indignation and dislike
                men who are so beguiled and demoralized by the pleasure of the
                desire that they cannot foresee.
            </p>

            <a href="<?php echo e(route('team')); ?>" class="btn btn-secondary">Meet All</a>
        </div>

        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $teams->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="single-team-member">
                        <div class="member-image">
                            <?php if($member->image): ?>
                                <img src="<?php echo e($member->image_url); ?>" alt="<?php echo e($member->name); ?>" />
                            <?php else: ?>
                                <img src="<?php echo e(asset('assets/img/placeholder.svg')); ?>" alt="<?php echo e($member->name); ?>" />
                            <?php endif; ?>

                            <a href="<?php echo e(route('team.member', $member->id)); ?>" class="details-btn">
                                <i class="fas fa-plus"></i>
                            </a>
                        </div>

                        <div class="member-content">
                            <h3><a href="<?php echo e(route('team.member', $member->id)); ?>"><?php echo e($member->name); ?></a></h3>
                            <span><?php echo e($member->designation); ?></span>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12">
                    <div class="text-center">
                        <p>No team members found.</p>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>
<!-- End Team Area -->
<?php /**PATH D:\BU\sadiq-sir-lab\resources\views/components/team.blade.php ENDPATH**/ ?>