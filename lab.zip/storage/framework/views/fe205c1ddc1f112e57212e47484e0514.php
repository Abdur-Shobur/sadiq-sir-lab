<!-- Start Boxes Area -->
<section class="boxes-area ptb-120">
    <div class="container">
        <div class="row section-title">
            <div class="col-12 text-center">
                <h2 style="max-width:100%"  >Research Areas</h2>
            </div>
        </div>
        <div class="row justify-content-center gy-4">
            <?php
                $researchAreas = \App\Models\ResearchArea::active()->ordered()->get();
            ?>

            <?php $__empty_1 = true; $__currentLoopData = $researchAreas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $researchArea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-lg-4 col-md-6 col-sm-6">
                    <div class="single-box h-100 <?php echo e($researchArea->background_color); ?>">
                        <div class="icon">
                            <?php if($researchArea->image): ?>
                                <img src="<?php echo e(asset('uploads/' . $researchArea->image)); ?>"
                                     alt="<?php echo e($researchArea->title); ?>"
                                     style="width: 80px; height: 80px; object-fit: cover; border-radius: 10px; filter: brightness(0) saturate(100%) invert(100%) sepia(0%) saturate(2%) hue-rotate(80deg) brightness(104%) contrast(100%);">
                            <?php else: ?>
                                <i class="flaticon-laboratory"></i>
                            <?php endif; ?>
                        </div>
                        <h3><?php echo e($researchArea->title); ?></h3>
                        <p><?php echo e($researchArea->description); ?></p>
                        <div class="shape-box">
                            <img src="<?php echo e(asset('assets/img/shape-image/9.png')); ?>" alt="image" />
                            <img src="<?php echo e(asset('assets/img/shape-image/10.png')); ?>" alt="image" />
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <!-- Fallback content if no research areas are found -->
                <div class="col-lg-4 col-md-6 col-sm-6">
                    <div class="single-box">
                        <div class="icon">
                            <img src="<?php echo e(asset('assets/img/performance-img1.png')); ?>" alt="Biotechnology Research" style="width: 80px; height: 80px; object-fit: cover; border-radius: 10px;">
                        </div>
                        <h3>Biotechnology Research</h3>
                        <p>
                            Advanced research in genetic engineering, molecular biology, and bioprocessing technologies.
                            Developing innovative solutions for healthcare, agriculture, and environmental sustainability.
                        </p>
                        <div class="shape-box">
                            <img src="<?php echo e(asset('assets/img/shape-image/9.png')); ?>" alt="image" />
                            <img src="<?php echo e(asset('assets/img/shape-image/10.png')); ?>" alt="image" />
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-6">
                    <div class="single-box bg-43c784">
                        <div class="icon">
                            <img src="<?php echo e(asset('assets/img/about-img1.png')); ?>" alt="Analytical Chemistry" style="width: 80px; height: 80px; object-fit: cover; border-radius: 10px;">
                        </div>
                        <h3>Analytical Chemistry</h3>
                        <p>
                            Cutting-edge analytical techniques and instrumentation for chemical analysis,
                            quality control, and research applications in pharmaceuticals and materials science.
                        </p>
                        <div class="shape-box">
                            <img src="<?php echo e(asset('assets/img/shape-image/9.png')); ?>" alt="image" />
                            <img src="<?php echo e(asset('assets/img/shape-image/10.png')); ?>" alt="image" />
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="single-box bg-f59f00">
                        <div class="icon">
                            <img src="<?php echo e(asset('assets/img/blog-img7.jpg')); ?>" alt="Environmental Science" style="width: 80px; height: 80px; object-fit: cover; border-radius: 10px;">
                        </div>
                        <h3>Environmental Science</h3>
                        <p>
                            Research focused on environmental monitoring, pollution control, and sustainable
                            development practices for a cleaner and healthier environment.
                        </p>
                        <div class="shape-box">
                            <img src="<?php echo e(asset('assets/img/shape-image/9.png')); ?>" alt="image" />
                            <img src="<?php echo e(asset('assets/img/shape-image/10.png')); ?>" alt="image" />
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>
<!-- End Boxes Area -->
<?php /**PATH D:\BU\sadiq-sir-lab\resources\views/components/boxes.blade.php ENDPATH**/ ?>