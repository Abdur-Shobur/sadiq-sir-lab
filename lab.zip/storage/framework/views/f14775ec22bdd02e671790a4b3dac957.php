

<?php $__env->startSection('content'); ?>
<div >
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0 text-gray-800">Team Details</h1>
        <div>
            <a href="<?php echo e(route('dashboard.teams.edit', $team)); ?>" class="btn btn-warning">
                <i class="fas fa-edit"></i>
                <span class="d-none d-lg-inline-block">Edit</span>
            </a>
            <a href="<?php echo e(route('dashboard.teams.index')); ?>" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i>
                <span class="d-none d-lg-inline-block">Back to List</span>
            </a>
        </div>
    </div>

    <div class="row">
        <div class="col-md-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Profile Information</h6>
                </div>
                <div class="card-body text-center">
                    <img src="<?php echo e($team->image_url); ?>" alt="<?php echo e($team->name); ?>"
                         class="img-fluid rounded-circle mb-3" style="width: 150px; height: 150px; object-fit: cover;">
                    <h4><?php echo e($team->name); ?></h4>
                    <p class="text-muted"><?php echo e($team->designation); ?></p>
                    <span class="badge badge-<?php echo e($team->role === 'admin' ? 'danger' : 'info'); ?> mb-2">
                        <?php echo e(ucfirst($team->role)); ?>

                    </span>
                    <div class="mt-3">
                        <span class="badge badge-<?php echo e($team->is_active ? 'success' : 'secondary'); ?>">
                            <?php echo e($team->is_active ? 'Active' : 'Inactive'); ?>

                        </span>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-8">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Contact Information</h6>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong>Email:</strong> <?php echo e($team->email); ?></p>
                            <p><strong>Phone:</strong> <?php echo e($team->phone ?: 'Not provided'); ?></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Website:</strong>
                                <?php if($team->website): ?>
                                    <a href="<?php echo e($team->website); ?>" target="_blank"><?php echo e($team->website); ?></a>
                                <?php else: ?>
                                    Not provided
                                <?php endif; ?>
                            </p>
                        </div>
                    </div>
                    <?php if($team->address): ?>
                        <p><strong>Address:</strong> <?php echo e($team->address); ?></p>
                    <?php endif; ?>
                </div>
            </div>

            <?php if($team->specialities): ?>
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Specialities</h6>
                </div>
                <div class="card-body">
                    <div class="row">
                        <?php $__currentLoopData = $team->specialities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $speciality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6">
                                <span class="badge badge-primary mr-2 mb-2"><?php echo e($speciality); ?></span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <?php if($team->education): ?>
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Education</h6>
                </div>
                <div class="card-body">
                    <ul class="list-unstyled">
                        <?php $__currentLoopData = $team->education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="mb-2"><i class="fas fa-graduation-cap text-primary mr-2"></i><?php echo e($education); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <?php endif; ?>

            <?php if($team->experience): ?>
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Experience</h6>
                </div>
                <div class="card-body">
                    <ul class="list-unstyled">
                        <?php $__currentLoopData = $team->experience; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="mb-2"><i class="fas fa-briefcase text-primary mr-2"></i><?php echo e($experience); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <?php endif; ?>

            <?php if($team->social_media): ?>
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Social Media</h6>
                </div>
                <div class="card-body">
                    <div class="row">
                        <?php $__currentLoopData = $team->social_media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6 mb-2">
                                <a href="<?php echo e($social['url']); ?>" target="_blank" class="btn btn-outline-primary btn-sm">
                                    <i class="fab fa-<?php echo e(strtolower($social['platform'])); ?>"></i> <?php echo e($social['platform']); ?>

                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\BU\sadiq-sir-lab\resources\views/dashboard/teams/show.blade.php ENDPATH**/ ?>