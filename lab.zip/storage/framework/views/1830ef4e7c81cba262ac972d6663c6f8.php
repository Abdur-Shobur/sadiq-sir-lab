<!-- Start Footer Area -->
<footer class="footer-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="single-footer-widget">
                    <div class="logo">
                        <a href="<?php echo e(route('home')); ?>">
                            <?php if(\App\Models\Setting::getValue('footer_logo')): ?>
                                <img style="max-height: 80px;" src="<?php echo e(asset('uploads/' . \App\Models\Setting::getValue('footer_logo'))); ?>" alt="<?php echo e(\App\Models\Setting::getValue('site_name', 'lab')); ?>" />
                            <?php else: ?>
                                <img style="max-height: 80px;" src="<?php echo e(asset('assets/img/logo.png')); ?>" alt="<?php echo e(\App\Models\Setting::getValue('site_name', 'lab')); ?>" />
                            <?php endif; ?>
                        </a>

                        <p>
                            <?php echo e(\App\Models\Setting::getValue('footer_description', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magnacing elit, sed do.')); ?>

                        </p>
                    </div>

                                        <div class="newsletter-box">
                        <h4>Newsletter</h4>

                        <?php if(session('success')): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <?php echo e(session('success')); ?>

                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php endif; ?>

                        <form class="newsletter-form" id="newsletterForm" action="<?php echo e(route('newsletter.subscribe')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="input-group">
                                <input
                                    type="email"
                                    class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="Your Email Address"
                                    name="email"
                                    value="<?php echo e(old('email')); ?>"
                                    required
                                    autocomplete="off"
                                />
                                <button style="z-index: 9; padding: 0" type="submit" class="btn btn-primary">
                                    <i class="fas fa-paper-plane"></i>
                                </button>
                            </div>
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </form>

                        <script>
                        document.addEventListener('DOMContentLoaded', function() {
                            const form = document.getElementById('newsletterForm');

                            form.addEventListener('submit', function(e) {
                                e.preventDefault();

                                const email = form.querySelector('input[name="email"]').value.trim();
                                if (!email) return;

                                // Show confirmation popup
                                Swal.fire({
                                    title: 'Subscribe to Newsletter?',
                                    text: `Are you sure you want to subscribe with ${email}?`,
                                    icon: 'question',
                                    showCancelButton: true,
                                    confirmButtonColor: '#3085d6',
                                    cancelButtonColor: '#d33',
                                    confirmButtonText: 'Yes, Subscribe!',
                                    cancelButtonText: 'Cancel'
                                }).then((result) => {
                                    if (result.isConfirmed) {
                                        // Submit the form
                                        form.submit();
                                    }
                                });
                            });
                        });
                        </script>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="single-footer-widget ms-5">
                    <h3>Useful Links</h3>

                    <ul class="useful-links-list">
                        <li><a href="<?php echo e(route('about')); ?>">About Us</a></li>
                        <li><a href="<?php echo e(route('contact')); ?>">Contacts</a></li>
                        <li><a href="<?php echo e(route('research')); ?>">Research</a></li>
                        <li><a href="<?php echo e(route('blog')); ?>">Blog</a></li>
                        <li><a href="<?php echo e(route('team.login')); ?>">Team Login</a></li>
                    </ul>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="single-footer-widget">
                    <h3>Our Project</h3>

                    <ul class="useful-links-list">
                        <?php
                            $recentProjects = \App\Models\Project::with('category')->active()->ordered()->take(5)->get();
                        ?>

                        <?php $__empty_1 = true; $__currentLoopData = $recentProjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li>
                                <a href="<?php echo e(route('project.details', $project->id)); ?>">
                                    <i class="fas fa-flask me-2"></i>
                                    <?php echo e(Str::limit($project->title, 30)); ?>

                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <li><span class="text-muted">No projects available</span></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="single-footer-widget">
                    <h3>Contact Info</h3>

                    <ul class="footer-contact-info">
                        <li>
                            <i class="fas fa-map-marker-alt"></i>
                            <?php echo e(\App\Models\Setting::getValue('contact_address', '49, Suitland Street, c.g square, USA')); ?>

                        </li>
                        <li>
                            <i class="fas fa-phone"></i>
                            <?php if(\App\Models\Setting::getValue('contact_phone')): ?>
                                <a href="tel:<?php echo e(\App\Models\Setting::getValue('contact_phone')); ?>"><?php echo e(\App\Models\Setting::getValue('contact_phone')); ?></a>
                            <?php else: ?>
                                <a href="tel:+199999999999">+1 999 9999 9999</a>
                            <?php endif; ?>
                        </li>

                        <li>
                            <i class="fas fa-envelope"></i>
                            <?php if(\App\Models\Setting::getValue('contact_email')): ?>
                                <a href="mailto:<?php echo e(\App\Models\Setting::getValue('contact_email')); ?>"><?php echo e(\App\Models\Setting::getValue('contact_email')); ?></a>
                            <?php endif; ?>
                        </li>
                        <li>
                            <i class="fas fa-globe"></i>
                            <?php if(\App\Models\Setting::getValue('contact_website')): ?>
                                <a href="<?php echo e(\App\Models\Setting::getValue('contact_website')); ?>" target="_blank"><?php echo e(str_replace(['https://', 'http://'], '', \App\Models\Setting::getValue('contact_website'))); ?></a>
                            <?php endif; ?>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="copyright-area">
            <div class="row align-items-center">
                <div class="col-lg-6 col-md-6 col-sm-6">
                    <p>
                        <?php echo e(\App\Models\Setting::getValue('footer_copyright', '© ' . date('Y') . '')); ?>

                    </p>
                </div>

                <div class="col-lg-6 col-md-6 col-sm-6">
                    <ul>
                        <?php
                            $socialMedia = \App\Models\SocialMedia::getActive();
                        ?>

                        <?php $__empty_1 = true; $__currentLoopData = $socialMedia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li>
                                <a href="<?php echo e($social->url); ?>" target="_blank" title="<?php echo e(ucfirst($social->platform)); ?>">
                                    <i class="<?php echo e($social->getIconClass()); ?>"></i>
                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <li>
                                <a href="#" class="text-muted">
                                    <i class="fas fa-share-alt"></i>
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- End Footer Area -->
<?php /**PATH D:\BU\sadiq-sir-lab\resources\views/components/footer.blade.php ENDPATH**/ ?>